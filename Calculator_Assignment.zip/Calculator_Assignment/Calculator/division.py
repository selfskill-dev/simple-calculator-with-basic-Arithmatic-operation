def division(x,y):
    return x/y